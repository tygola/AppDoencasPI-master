<?php
 
class DbOperation
{
    
    private $con;
    function __construct()
    {
        require_once dirname(__FILE__) . '/DbConnect.php';
        $db = new DbConnect();
         $this->con = $db->connect();
    }
	
	function createDoenca($nome, $sintomas, $prevencao){
		$stmt = $this->con->prepare("INSERT INTO tbDoencas (nome, sintomas, prevencao) VALUES (?, ?, ?)");
		$stmt->bind_param("sss", $nome, $sintomas, $prevencao);
		if($stmt->execute())
			return true; 
		return false; 
	}

	function getDoenca(){
		$stmt = $this->con->prepare("SELECT id, nome, sintomas, prevencao FROM tbDoencas");
		$stmt->execute();
		$stmt->bind_result($id, $nome, $sintomas, $prevencao);
		$doencas = array(); 
	
		while($stmt->fetch()){
			$doeca  = array();
			$doenca['id'] = $id; 
			$doenca['nome'] = $nome; 
			$doenca['sintomas'] = $sintomas; 
			$doenca['prevencao'] = $prevencao; 
			
			array_push($doencas, $doenca); 
		}
		
		return $doencas; 
	}
	
	function updateDoenca($id, $nome, $sintomas, $prevencao){
		$stmt = $this->con->prepare("UPDATE tbDoencas SET nome = ?, sintomas = ?, prevencao = ? WHERE id = ?");
		$stmt->bind_param("sssi", $nome, $sintomas, $prevencao, $id);
		if($stmt->execute())
			return true; 
		return false; 
	}
	
	
	function deleteDoenca($id){
		$stmt = $this->con->prepare("DELETE FROM tbDoencas WHERE id = ? ");
		$stmt->bind_param("i", $id);
		if($stmt->execute())
			return true; 
		
		return false; 
	}
}