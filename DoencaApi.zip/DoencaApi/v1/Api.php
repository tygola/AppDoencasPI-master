<?php 

	require_once '../includes/DbOperation.php';

	function isTheseParametersAvailable($params){
	
		$available = true; 
		$missingparams = ""; 
		
		foreach($params as $param){
			if(!isset($_POST[$param]) || strlen($_POST[$param])<=0){
				$available = false; 
				$missingparams = $missingparams . ", " . $param; 
			}
		}
		
		
		if(!$available){
			$response = array(); 
			$response['error'] = true; 
			$response['message'] = 'Parameters ' . substr($missingparams, 1, strlen($missingparams)) . ' missing';
			
		
			echo json_encode($response);
			
		
			die();
		}
	}
	
	
	$response = array();
	

	if(isset($_GET['apicall'])){
		
		switch($_GET['apicall']){
	
			case 'createDoenca':
				
				isTheseParametersAvailable(array('nome','sintomas','prevencao'));
				
				$db = new DbOperation();
				
				$result = $db->createDoenca(
					$_POST['nome'],
					$_POST['sintomas'],
					$_POST['prevencao']
				);
				

			
				if($result){
					
					$response['error'] = false; 

					
					$response['message'] = 'Doenca adicionada com sucesso';

					
					$response['doencas'] = $db->getDoenca();
				}else{

					
					$response['error'] = true; 

				
					$response['message'] = 'Erro ao adicionar a doenca!!!';
				}
				
			break; 
			
		
			case 'getDoenca':
				$db = new DbOperation();
				$response['error'] = false; 
				$response['message'] = 'Doenca selecionada com sucesso!!!';
				$response['doencas'] = $db->getDoenca();
			break; 
			
			
		
			case 'updateDoenca':
				isTheseParametersAvailable(array('id','nome','sintomas','prevencao'));
				$db = new DbOperation();
				$result = $db->updateDoenca(
					$_POST['id'],
					$_POST['nome'],
					$_POST['sintomas'],
					$_POST['prevencao']
				);
				
				if($result){
					$response['error'] = false; 
					$response['message'] = 'Doenca alterado com sucesso';
					$response['doencas'] = $db->getDoenca();
				}else{
					$response['error'] = true; 
					$response['message'] = 'Erro ao alterar!!!';
				}
			break; 
			
			
			case 'deleteDoenca':

				
				if(isset($_GET['id'])){
					$db = new DbOperation();
					if($db->deleteDoenca($_GET['id'])){
						$response['error'] = false; 
						$response['message'] = 'Doenca excluída com sucesso';
						$response['doencas'] = $db->getDoenca();
					}else{
						$response['error'] = true; 
						$response['message'] = 'Erro ao excluir!!!';
					}
				}else{
					$response['error'] = true; 
					$response['message'] = 'Favor inserir o id.';
				}
			break; 
		}
		
	}else{
		 
		$response['error'] = true; 
		$response['message'] = 'Chamada de API inválida';
	}
	
	echo json_encode($response);
	
	
